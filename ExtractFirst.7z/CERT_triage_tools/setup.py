#!/usr/bin/env python
### BEGIN LICENSE ###
### Use of the CERT Basic Fuzzing Framework (BFF) and related source code is
### subject to the following terms:
### 
### # LICENSE #
### 
### Copyright (C) 2010-2016 Carnegie Mellon University. All Rights Reserved.
### 
### Redistribution and use in source and binary forms, with or without
### modification, are permitted provided that the following conditions are met:
### 
### 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following acknowledgments and disclaimers.
### 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following acknowledgments and disclaimers in the documentation and/or other materials provided with the distribution.
### 3. Products derived from this software may not include "Carnegie Mellon University," "SEI" and/or "Software Engineering Institute" in the name of such derived product, nor shall "Carnegie Mellon University," "SEI" and/or "Software Engineering Institute" be used to endorse or promote products derived from this software without prior written permission. For written permission, please contact permission@sei.cmu.edu.
### 
### # ACKNOWLEDGMENTS AND DISCLAIMERS: #
### Copyright (C) 2010-2016 Carnegie Mellon University
### 
### This material is based upon work funded and supported by the Department of
### Homeland Security under Contract No. FA8721-05-C-0003 with Carnegie Mellon
### University for the operation of the Software Engineering Institute, a federally
### funded research and development center.
### 
### Any opinions, findings and conclusions or recommendations expressed in this
### material are those of the author(s) and do not necessarily reflect the views of
### the United States Departments of Defense or Homeland Security.
### 
### NO WARRANTY. THIS CARNEGIE MELLON UNIVERSITY AND SOFTWARE ENGINEERING INSTITUTE
### MATERIAL IS FURNISHED ON AN "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO
### WARRANTIES OF ANY KIND, EITHER EXPRESSED OR IMPLIED, AS TO ANY MATTER
### INCLUDING, BUT NOT LIMITED TO, WARRANTY OF FITNESS FOR PURPOSE OR
### MERCHANTABILITY, EXCLUSIVITY, OR RESULTS OBTAINED FROM USE OF THE MATERIAL.
### CARNEGIE MELLON UNIVERSITY DOES NOT MAKE ANY WARRANTY OF ANY KIND WITH RESPECT
### TO FREEDOM FROM PATENT, TRADEMARK, OR COPYRIGHT INFRINGEMENT.
### 
### This material has been approved for public release and unlimited distribution.
### 
### CERT(R) is a registered mark of Carnegie Mellon University.
### 
### DM-0000736
### END LICENSE ###

# The MIT License (MIT)
# 
# Copyright (c) 2013 Jonathan Foote
# 
# Permission is hereby granted, free of charge, to any person obtaining a copy of
# this software and associated documentation files (the "Software"), to deal in
# the Software without restriction, including without limitation the rights to
# use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
# the Software, and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
# FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
# COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
# IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

import os
from optparse import OptionParser

def run(cmd):
    import subprocess, shlex
    print cmd
    subprocess.check_call(shlex.split(cmd))

if __name__ == "__main__":
    usage = "usage: %prog install|uninstall|test [path]"
    desc = "[Un]installs exploitable gdb plugin to PATH, or GDB data dir if no "  +\
           "path is specified."
        
    op = OptionParser(description=desc, usage=usage)

    (opts, args) = op.parse_args()
    if len(args) < 1:
        op.error("wrong number of arguments")
    if len(args) == 1:
        import subprocess, shlex, re
        path = subprocess.check_output(shlex.split(
            "gdb --batch -ex 'show data-directory'")).strip()
        match = re.match("^.*\"(.*)\".*$", path)
        if not match:
            raise Exception("GDB data directory parse command failed, "
                    "make sure GDB is installed and try specifying a path "
                    "manually")
        path = match.groups()[0]
    elif len(args) == 2:
        path = args[1]
    path = os.path.join(path, 'python', 'gdb', 'command')
    print "Target path is %s" % path
    if args[0] == "install":
        from shutil import copy, move
        run("cp -R exploitable/ %s/exploitable_lib" % path)
        run("touch %s/exploitable_lib/__init__.py" % path)
        run("cp gdb_install_stub.py %s/exploitable.py" % path)
    elif args[0] == "uninstall":
        run("rm %s/exploitable.py" % path)
        run("rm -rf %s/exploitable_lib" % path)
    elif args[0] == "test":
        if len(args) == 2:
            op.error("y u specify path with test?")
        print "testing for x86, for ARM and more args, see scripts in test/ dir"
        run("test/x86.sh build run_test clean")
        print "done"
    else:
        op.error("first arg is incorrect")
