### BEGIN LICENSE ###
### Use of the CERT Basic Fuzzing Framework (BFF) and related source code is
### subject to the following terms:
### 
### # LICENSE #
### 
### Copyright (C) 2010-2016 Carnegie Mellon University. All Rights Reserved.
### 
### Redistribution and use in source and binary forms, with or without
### modification, are permitted provided that the following conditions are met:
### 
### 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following acknowledgments and disclaimers.
### 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following acknowledgments and disclaimers in the documentation and/or other materials provided with the distribution.
### 3. Products derived from this software may not include "Carnegie Mellon University," "SEI" and/or "Software Engineering Institute" in the name of such derived product, nor shall "Carnegie Mellon University," "SEI" and/or "Software Engineering Institute" be used to endorse or promote products derived from this software without prior written permission. For written permission, please contact permission@sei.cmu.edu.
### 
### # ACKNOWLEDGMENTS AND DISCLAIMERS: #
### Copyright (C) 2010-2016 Carnegie Mellon University
### 
### This material is based upon work funded and supported by the Department of
### Homeland Security under Contract No. FA8721-05-C-0003 with Carnegie Mellon
### University for the operation of the Software Engineering Institute, a federally
### funded research and development center.
### 
### Any opinions, findings and conclusions or recommendations expressed in this
### material are those of the author(s) and do not necessarily reflect the views of
### the United States Departments of Defense or Homeland Security.
### 
### NO WARRANTY. THIS CARNEGIE MELLON UNIVERSITY AND SOFTWARE ENGINEERING INSTITUTE
### MATERIAL IS FURNISHED ON AN "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO
### WARRANTIES OF ANY KIND, EITHER EXPRESSED OR IMPLIED, AS TO ANY MATTER
### INCLUDING, BUT NOT LIMITED TO, WARRANTY OF FITNESS FOR PURPOSE OR
### MERCHANTABILITY, EXCLUSIVITY, OR RESULTS OBTAINED FROM USE OF THE MATERIAL.
### CARNEGIE MELLON UNIVERSITY DOES NOT MAKE ANY WARRANTY OF ANY KIND WITH RESPECT
### TO FREEDOM FROM PATENT, TRADEMARK, OR COPYRIGHT INFRINGEMENT.
### 
### This material has been approved for public release and unlimited distribution.
### 
### CERT(R) is a registered mark of Carnegie Mellon University.
### 
### DM-0000736
### END LICENSE ###

'''
Created on Apr 11, 2011

@organization: cert.org
'''
import time
import tempfile
import os
import shutil
import unittest
import sys

mydir = os.path.dirname(os.path.abspath(__file__))
parentdir = os.path.abspath(os.path.join(mydir, '..'))
sys.path.append(parentdir)

import certfuzz.bff.linux as bff

class Mock(object):
    def __init__(self):
        self.is_crash = True
        self.is_assert_fail = False
        self.registers_hex = {'eip': '0xdeadbeef'}
        self.debugger_missed_stack_corruption = False
        self.total_stack_corruption = False

    def go(self):
        return Mock()

    def get_crash_signature(self, dummy):
        return os.urandom(10)

class Test(unittest.TestCase):
    def setUp(self):
        pass
    def tearDown(self):
        pass
#    def test_get_rate(self):
#        bff.SEED_TS = Mock()
#        bff.SEED_TS.since_start = lambda: 1.0
#        for i in range(100):
#            self.assertEqual(float(i / 1.0), bff.get_rate(i))
#
#    def test_get_uniq_logger(self):
#        logfile = tempfile.mktemp()
#        ulog = bff.get_uniq_logger(logfile)
#        self.assertEqual('Logger', ulog.__class__.__name__)
#        self.assertEqual(0, os.path.getsize(logfile))
#        msg = 'foo'
#        ulog.warning(msg)
#        # length is msg + a carriage return
#        self.assertEqual(len(msg) + 1, os.path.getsize(logfile))
#        os.remove(logfile)
#        self.assertFalse(os.path.exists(logfile))

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.test_load_obj_from_file']
    unittest.main()
